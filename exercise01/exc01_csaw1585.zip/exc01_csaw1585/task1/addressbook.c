#include "addressbook.h"

bool compare_contact(contact_t* contact, char* first_name, char* last_name) {
	if (strcmp(contact->first_name, first_name) == 0 && strcmp(contact->last_name, last_name) == 0) {
		return true;
	}
	return false;
}

address_book_t* create_address_book() {
	address_book_t* tmp = malloc(sizeof(address_book_t));

	if (tmp == NULL) {
		perror("Error while allocating memory!\n");
	}

	tmp->head = NULL;
	return tmp;
}

contact_t* create_contact(char* first_name, char* last_name, int age, char* email) {
	contact_t* tmp = malloc(sizeof(contact_t));

	if (tmp == NULL) {
		perror("Error while allocating memory!\n");
	}

	// initialize strings
	strcpy(tmp->first_name, first_name);
	strcpy(tmp->last_name, last_name);
	strcpy(tmp->email, email);
	tmp->age = age;
	return tmp;
}

void add_contact(address_book_t* address_book, contact_t* contact) {
	if (address_book == NULL || contact == NULL) {
		perror("NULL value was supplied!");
	}

	node_t* tmp = malloc(sizeof(node_t));
	if (tmp == NULL) {
		perror("Error while allocating memory!\n");
	}

	tmp->data = contact;
	tmp->next = NULL;

	// no contacts in addressbook yet
	if (address_book->head == NULL) {
		address_book->head = tmp;
	}
	// finding last entry
	else {
		node_t* iterator = address_book->head;
		while (iterator->next != NULL) {
			iterator = iterator->next;
		}
		iterator->next = tmp;
	}
}

contact_t* find_contact(address_book_t* address_book, char* first_name, char* last_name) {
	node_t* iterator = address_book->head;
	while (iterator != NULL) {
		if (compare_contact(iterator->data, first_name, last_name) == true) {
			return iterator->data;
		}
		iterator = iterator->next;
	}
	// no matching contact was found
	return NULL;
}

void remove_contact(address_book_t* address_book, contact_t* contact) {
	if (contact == NULL) {
		return;
	}

	node_t* prev = address_book->head;
	// base case: head is contact
	if (prev->data == contact) {
		address_book->head = prev->next;
		free(prev->data);
		free(prev);
		return;
	}

	// other cases
	node_t* iterator = address_book->head->next;
	while (iterator != NULL) {
		if (iterator->data == contact) {
			prev->next = iterator->next;
			free(iterator->data);
			free(iterator);
			return;
		} else {
			iterator = iterator->next;
			prev = prev->next;
		}
	}
}

void print_address_book(address_book_t* address_book) {
	node_t* current = address_book->head;
	while (current != NULL) {
		contact_t* contact = (contact_t*)current->data;
		printf("%s %s, %d, %s\n", contact->first_name, contact->last_name, contact->age,
		       contact->email);
		current = current->next;
	}
}

contact_t* duplicate_contact(contact_t* contact) {
	return create_contact(contact->first_name, contact->first_name, contact->age, contact->email);
}

address_book_t* filter_address_book(address_book_t* address_book, bool (*filter)(contact_t*)) {
	if (address_book == NULL) {
		perror("Address book is NULL.");
	}
	address_book_t* tmp = create_address_book();
	node_t* iterator = address_book->head;

	while (iterator != NULL) {
		if (filter(iterator->data) == true) {
			add_contact(tmp, iterator->data);
		}
		iterator = iterator->next;
	}
	return tmp;
}

// adaption of swap example from: https://iq.opengenus.org/bubble-sort-on-linked-list/
void swap(node_t* node1, node_t* node2) {
	void* tmp = node1->data;
	node1->data = node2->data;
	node2->data = tmp;
}

// adaption of bubble sort example from: https://iq.opengenus.org/bubble-sort-on-linked-list/
void sort_address_book(address_book_t* address_book, bool (*compare)(contact_t*, contact_t*)) {
	if (address_book->head == NULL) {
		perror("Empty address_book to sort!");
	}

	bool swapped = true;
	node_t* node1;
	node_t* l_node = NULL;

	do {
		swapped = false;
		node1 = address_book->head;

		while (node1->next != l_node) {
			if (compare(node1->data, node1->next->data) == false) {
				swap(node1, node1->next);
				swapped = true;
			}
			node1 = node1->next;
		}
		l_node = node1;
	} while (swapped);
}

bool compare_by_name(contact_t* contact1, contact_t* contact2) {
	if (contact1 == NULL || contact2 == NULL) {
		perror("At least one contact was NULL, no comparision possible!");
	}

	int first_name_r = strcmp(contact1->first_name, contact2->first_name);
	int last_name_r = strcmp(contact1->last_name, contact2->last_name);

	if (first_name_r < 0) {
		return true;
	} else if (first_name_r == 0) {
		if (last_name_r <= 0) {
			return true;
		}
	}
	return false;
}

bool is_adult(contact_t* contact) {
	if (contact == NULL) {
		perror("Contact is NULL");
	}

	return contact->age > 17 ? true : false;
}

size_t count_contacts(address_book_t* address_book) {
	node_t* iterator = address_book->head;
	size_t counter = 0;
	while (iterator != NULL) {
		counter++;
		iterator = iterator->next;
	}
	return counter;
}

void free_address_book(address_book_t* address_book) {
	if (address_book == NULL) {
		return;
	}
	node_t* iterator = address_book->head;
	while (iterator != NULL) {
		node_t* tmp = iterator;
		iterator = iterator->next;
		if (tmp->data != NULL) {
			free(tmp->data);
		}
		free(tmp);
	}
	free(address_book);
}