#include "testing.h"

int __tt__test_count__ = 0;
int __tt__test_failed__ = 0;