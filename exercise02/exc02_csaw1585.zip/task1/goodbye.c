#include "goodbye.h"
#include <stdio.h>

void goodbye(void) {
	puts("Bye World.");
}
