#include "hello.h"
#include <stdio.h>

void hello(void) {
	puts("Hello World.");
}
