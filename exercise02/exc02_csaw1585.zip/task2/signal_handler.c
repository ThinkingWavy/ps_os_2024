#define _POSIX_C_SOURCE
#define _BSD_SOURCE

#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static void handler(int signum) {
	switch (signum) {
		case (SIGINT): write(1, "The signal SIGINT was sent!\n", 29); break;
		case (SIGCONT): write(1, "The signal SIGCONT was sent!\n", 30); break;
		case (SIGKILL): write(1, "The signal SIGKILL was sent!\n", 30); break;
		case (SIGSTOP): write(1, "The signal SIGSTOP was sent!\n", 30); break;
		case (SIGUSR1): write(1, "The signal SIGUSR1 was sent!\n", 30); break;
		case (SIGUSR2): write(1, "The signal SIGUSR2 was sent!\n", 30); break;
	}
}

int main(void) {
	struct sigaction sig;

	memset(&sig, 0, sizeof(sig));

	sig.sa_handler = handler;
	sigaction(SIGINT, &sig, NULL);  // id: 2
	sigaction(SIGCONT, &sig, NULL); // id: 18
	sigaction(SIGSTOP, &sig, NULL); // id: 19
	sigaction(SIGKILL, &sig, NULL); // id: 9 -> not catchable
	sigaction(SIGUSR1, &sig, NULL); // user custom  signal
	sigaction(SIGUSR2, &sig, NULL); // user custom signal

	while (1) {
		usleep(100);
	}
	return EXIT_SUCCESS;
}